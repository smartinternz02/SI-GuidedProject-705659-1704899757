
/**
 * This class is generated automatically by Katalon Studio and should not be modified or deleted.
 */

import java.lang.String

import com.kms.katalon.core.testobject.TestObject



def static "com.example.WebUICustomKeywords.printHello"() {
    (new com.example.WebUICustomKeywords()).printHello()
}


def static "com.example.WebUICustomKeywords.printName"(
    	String name	) {
    (new com.example.WebUICustomKeywords()).printName(
        	name)
}


def static "com.example.WebUICustomKeywords.CheckDropDownListElementExist"(
    	TestObject object	
     , 	String option	) {
    (new com.example.WebUICustomKeywords()).CheckDropDownListElementExist(
        	object
         , 	option)
}
